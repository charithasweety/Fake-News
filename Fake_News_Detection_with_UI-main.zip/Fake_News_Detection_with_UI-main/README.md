# Fake_News_Detection_with_UI
Fake News Detection NLP Model Building, Deployment Using Flask

Directory Structure:
- Deploy_Directory
    - templates 
        - index.html
    - app.py
    - data file
